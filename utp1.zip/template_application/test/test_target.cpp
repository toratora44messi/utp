#include "gtest/gtest.h"
#include "target.h"
#include "singletonA.h"

class TargetTest : public ::testing::Test {
protected:
    void SetUp() override {
        // Make sure the singleton instance is created before each test
        singletonA::createInstance();
    }
};

TEST_F(TargetTest, getNumAdds5WhenInitialNumberIsLessThan18) {
    // Arrange
    target t;
    // Act
    int num = t.getNum(target::eType_A);
    // Assert
    EXPECT_EQ(num, 16); // 11 + 5 = 16
}

TEST_F(TargetTest, getNumAdds10WhenInitialNumberIsGreaterThanOrEqualTo18) {
    // Arrange
    target t;
    // Act
    int num = t.getNum(target::eType_B);
    // Assert
    EXPECT_EQ(num, 28); // 18 + 10 = 28
}

TEST_F(TargetTest, getNumReturnsMinus1WhenTypeIsInvalid) {
    // Arrange
    target t;
    // Act
    int num = t.getNum(static_cast<target::EType>(-1));
    // Assert
    EXPECT_EQ(num, -1);
}

TEST_F(TargetTest, getNumDoesNotAddToNumberWhenInitialNumberIsGreaterThanOrEqualTo100) {
    // Arrange
    target t;
    // Act
    int num = t.getNum(target::eType_C);
    // Assert
    EXPECT_EQ(num, 110); // 100 + 10 = 110
}