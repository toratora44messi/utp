#ifndef SINGLETON_B_H
#define SINGLETON_B_H

class singletonB
{
private:
    singletonB(/* args */);
public:
    ~singletonB();
    static singletonB* createInstance();
    static singletonB* getIntance();
    bool getName_B(char* name, int size);
    bool setName_B(char* name, int size);
    void clearName_B();
private:
    static singletonB* fgB_Obj;
    char fName[128+1];
};
#endif //SINGLETON_B_H
