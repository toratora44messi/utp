#ifndef SINGLETON_C_H
#define SINGLETON_C_H
class singletonC
{
private:
    singletonC(/* args */);
public:
    ~singletonC();
    static singletonC* createInstance();
    static singletonC* getIntance();
    

private:
    static singletonC* fgC_Obj;
};
#endif //SINGLETON_C_H