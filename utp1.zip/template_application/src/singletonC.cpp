#include "singletonC.h"

singletonC* singletonC::fgC_Obj = 0;

singletonC::singletonC(/* args */)
{
}

singletonC::~singletonC()
{
}

singletonC* singletonC::createInstance()
{
    if (fgC_Obj != 0) {
        return fgC_Obj;
    }

    fgC_Obj = new singletonC();

    return fgC_Obj;
}

singletonC* singletonC::getIntance()
{
    return fgC_Obj;
}