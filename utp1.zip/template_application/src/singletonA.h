#ifndef SINGLETON_A_H
#define SINGLETON_A_H
class singletonA
{
private:
    singletonA(/* args */);
public:
    ~singletonA();
    static singletonA* createInstance();
    static singletonA* getIntance();
    bool getNumber(int* number);


private:
    static singletonA* fgA_Obj;
};

#endif // SINGLETON_A_H