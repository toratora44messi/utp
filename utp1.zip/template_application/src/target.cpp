#include "target.h"
#include "singletonA.h"

target::target()
{
}

target::~target()
{
}

int target::getNum(target::EType type){
    int num;
    switch(type) {
    case target::eType_A:
        num = 11;
        break;
    case target::eType_B:
        num = 18;
        break;
    case target::eType_C:
        num = 100;
        break;
    default:
        return -1;
    }
    bool ret = singletonA::getIntance()->getNumber(&num);

    if (!ret) {
        num = -1;
    }
    
    return num;
}
